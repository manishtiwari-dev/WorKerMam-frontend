<?php
return [
    'lead' => 'lead',
    'lead_setting' => 'lead_setting',
    'clients' => 'clients',
    'lead-followup'=>'lead_followup'

];