<?php
return [
    'setting' => 'hrm-setting',
    'Staff' => 'staff',
    'hrm-leave' => 'leave',
    'hrm-holiday' => 'holiday',
    'hrm-attendance' => 'attendance',
    'hrm-salary' => 'hrm-salary',
    'hrm-report' => ' hrm-report',

];
