<?php
return [
    'general_setting' => 'seo_general_setting',
    'submission_url' => 'seo_submission_url',
    'daily_work' => 'daily_work',
    'work_report' => 'work_report',
    'monthly_result' => 'monthly_result',
    'web_redirects'=>'web_redirects',
];
