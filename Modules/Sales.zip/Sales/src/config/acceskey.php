<?php
return [
     'sales-customer' => 'customer',
     'sales-order' => 'orders',
     'sales-enquiry' => 'sales-enquiry',
     'sales-quotation' => 'quotation',
     'account-setting' => 'account-setting',
     'sales-transaction' => 'transaction',
     'sales-calendar' => 'account-calendar',
     'sales-report' => 'account-report',
     'sales-custom-quote' => 'custom_quote',
     'sales-invoice' => 'invoice'
];
