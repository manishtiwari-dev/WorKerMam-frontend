<?php
return [
    'tax-setting' => 'tax-setting',
    'payment-term' => 'payment_term',
    'payment-setting' => 'payment-setting',
    'general-setting' => 'general-setting',


];
